#!/bin/sh
java -classpath "./PTRuntime-dev.jar:./flickrapi-1.2.jar:./ParaImage.jar"  pt.examples.ParaImage.MainFrame
