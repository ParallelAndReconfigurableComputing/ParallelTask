package spoon.reflect.declaration.testclasses;

public interface TestInterface {
}
