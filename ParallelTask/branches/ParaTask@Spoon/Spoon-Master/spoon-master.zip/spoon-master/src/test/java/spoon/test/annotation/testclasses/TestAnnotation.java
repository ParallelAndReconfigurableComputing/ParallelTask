package spoon.test.annotation.testclasses;

public @interface TestAnnotation
{
}
