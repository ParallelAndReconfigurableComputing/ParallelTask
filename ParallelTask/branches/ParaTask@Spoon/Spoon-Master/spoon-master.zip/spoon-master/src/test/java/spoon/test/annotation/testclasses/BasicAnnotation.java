package spoon.test.annotation.testclasses;

public interface BasicAnnotation<T> {
}
