package spoon.reflect.declaration.testclasses;

public class ExtendsObject {
}
