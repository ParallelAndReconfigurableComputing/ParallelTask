package spoon.support.compiler.jdt;

public class ExtendedStringLiteralClass {

	final public static String extendedStringLiteral = "hello "+"world!";
	
}
