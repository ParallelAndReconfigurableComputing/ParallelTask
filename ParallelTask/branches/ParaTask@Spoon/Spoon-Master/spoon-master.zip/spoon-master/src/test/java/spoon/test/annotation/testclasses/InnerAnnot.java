package spoon.test.annotation.testclasses;

public @interface InnerAnnot
{
	String value();
}
