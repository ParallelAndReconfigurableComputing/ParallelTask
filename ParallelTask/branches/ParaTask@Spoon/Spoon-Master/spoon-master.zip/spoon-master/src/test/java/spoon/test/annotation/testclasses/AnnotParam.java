package spoon.test.annotation.testclasses;


public class AnnotParam {

	@SuppressWarnings({"unused","rawtypes"})
	public void m(int a) {
	} 

}
