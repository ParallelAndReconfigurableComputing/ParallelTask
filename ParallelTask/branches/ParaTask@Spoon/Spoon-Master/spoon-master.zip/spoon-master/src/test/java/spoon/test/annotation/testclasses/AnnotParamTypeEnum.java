package spoon.test.annotation.testclasses;

@TestAnnotation
public enum AnnotParamTypeEnum
{
	@TestAnnotation
	R,

	@TestAnnotation
	G,

	@TestAnnotation
	B
}
