package spoon.test;

import spoon.reflect.visitor.CtAbstractVisitor;

/**
 * Created by nicolas on 12/01/2015.
 */
public class VisitorTest extends CtAbstractVisitor {
	/**
	 * This visitor implementation should always be empty :
	 *
	 * ensure that we have correctly defined all visit method in CtAbstractVisitor.
	 */
}
