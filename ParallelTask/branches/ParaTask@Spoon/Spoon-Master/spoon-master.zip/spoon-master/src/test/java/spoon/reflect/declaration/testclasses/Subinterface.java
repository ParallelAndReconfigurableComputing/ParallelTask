package spoon.reflect.declaration.testclasses;

public interface Subinterface extends TestInterface, Comparable<Object> {
	void foo();
}
