package android.os;

public class Handler {
	
	public Handler(Looper l) {
		throw new UnsupportedOperationException("This binary should NOT be included in the Parallel Task library jar.");
	}
	
	public final boolean post(Runnable r) { 
		throw new UnsupportedOperationException("This binary should NOT be included in the Parallel Task library jar.");
	}
}
