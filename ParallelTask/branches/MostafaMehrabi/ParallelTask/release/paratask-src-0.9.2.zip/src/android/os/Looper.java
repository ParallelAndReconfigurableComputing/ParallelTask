package android.os;

public class Looper {

	public static Looper myLooper() {
		throw new UnsupportedOperationException("This binary should NOT be included in the Parallel Task library jar.");
	}
	
	public static Looper getMainLooper() {
		throw new UnsupportedOperationException("This binary should NOT be included in the Parallel Task library jar.");
	}
	
	public Thread getThread() {
		throw new UnsupportedOperationException("This binary should NOT be included in the Parallel Task library jar.");
	}
}
