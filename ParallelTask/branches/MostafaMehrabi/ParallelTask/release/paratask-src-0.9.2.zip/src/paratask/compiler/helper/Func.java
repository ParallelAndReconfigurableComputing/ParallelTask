package paratask.compiler.helper;

public interface Func<E, T> {
	E map(T object);
}
