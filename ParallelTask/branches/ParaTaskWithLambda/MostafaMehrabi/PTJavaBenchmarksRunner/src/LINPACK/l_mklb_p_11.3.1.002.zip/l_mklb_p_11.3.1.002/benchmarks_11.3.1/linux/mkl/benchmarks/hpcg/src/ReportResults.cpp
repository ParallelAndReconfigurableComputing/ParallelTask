/******************************************************************************
*  Copyright(C) 2014 Intel Corporation. All rights reserved.
*
*  The source code, information  and  material ("Material") contained herein is
*  owned  by Intel Corporation or its suppliers or licensors, and title to such
*  Material remains  with Intel Corporation  or its suppliers or licensors. The
*  Material  contains proprietary information  of  Intel or  its  suppliers and
*  licensors. The  Material is protected by worldwide copyright laws and treaty
*  provisions. No  part  of  the  Material  may  be  used,  copied, reproduced,
*  modified, published, uploaded, posted, transmitted, distributed or disclosed
*  in any way  without Intel's  prior  express written  permission. No  license
*  under  any patent, copyright  or  other intellectual property rights  in the
*  Material  is  granted  to  or  conferred  upon  you,  either  expressly,  by
*  implication, inducement,  estoppel or  otherwise.  Any  license  under  such
*  intellectual  property  rights must  be express  and  approved  by  Intel in
*  writing.
*
*  *Third Party trademarks are the property of their respective owners.
*
*  Unless otherwise  agreed  by Intel  in writing, you may not remove  or alter
*  this  notice or  any other notice embedded  in Materials by Intel or Intel's
*  suppliers or licensors in any way.
*
*******************************************************************************/

//@HEADER
// ***************************************************
//
// HPCG: High Performance Conjugate Gradient Benchmark
//
// Contact:
// Michael A. Heroux ( maherou@sandia.gov)
// Jack Dongarra     (dongarra@eecs.utk.edu)
// Piotr Luszczek    (luszczek@eecs.utk.edu)
//
// ***************************************************
//@HEADER

/*!
 @file ReportResults.cpp

 HPCG routine
 */

#include <cstring>

#ifndef HPCG_OFFLOAD
#ifndef HPCG_NO_MPI
#include "mpi_hpcg.hpp"
#endif
#else
#include "offloadExtHpcgLib.hpp"
#endif

#include "ReportResults.hpp"
#include "YAML_Element.hpp"
#include "YAML_Doc.hpp"
#include "ExchangeHalo.hpp"

#ifdef HPCG_DEBUG
#include <fstream>
using std::endl;

#include "hpcg.hpp"
#endif

extern double forwardTime, backwardTime;

/*!
 Creates a YAML file and writes the information about the HPCG run, its results, and validity.

  @param[in] geom The description of the problem's geometry.
  @param[in] A    The known system matrix
  @param[in] numberOfMgLevels Number of levels in multigrid V cycle
  @param[in] numberOfCgSets Number of CG runs performed
  @param[in] niters Number of preconditioned CG iterations performed to lower the residual below a threshold
  @param[in] times  Vector of cumulative timings for each of the phases of a preconditioned CG iteration
  @param[in] testcg_data    the data structure with the results of the CG-correctness test including pass/fail information
  @param[in] testsymmetry_data the data structure with the results of the CG symmetry test including pass/fail information
  @param[in] testnorms_data the data structure with the results of the CG norm test including pass/fail information
  @param[in] global_failure indicates whether a failure occured during the correctness tests of CG

  @see YAML_Doc
*/
double ReportResults(const SparseMatrix & A, int numberOfMgLevels, int numberOfCgSets, int refMaxIters,int optMaxIters, double times[],
    const double mgTimes[], const double preSmoothTimes[], const double postSmoothTimes[], const double spmvTimes[], const double restrictionTimes[], const double prolongationTimes[],
    const double haloTimes[],
    const TestCGData & testcg_data, const TestSymmetryData & testsymmetry_data, const TestNormsData & testnorms_data, int global_failure,
    const HPCG_Params& params) {

  double minOfficialTime = 1800; // Any official benchmark result much run at least this many seconds

#ifndef HPCG_NO_MPI
  double t4 = times[4];
  double t4min = 0.0;
  double t4max = 0.0;
  double t4avg = 0.0;
  double totalGflops = -1.0;
#ifndef HPCG_OFFLOAD
  int errorCode = MPI_Allreduce(&t4, &t4min, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
  handleMPIError(errorCode);
  errorCode = MPI_Allreduce(&t4, &t4max, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
  handleMPIError(errorCode);
  errorCode = MPI_Allreduce(&t4, &t4avg, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
  handleMPIError(errorCode);
#else
  gbl_offload_dbl = t4;
  gbl_offload_signal = HPCG_OFFLOAD_ALLRED_DBL_MIN;
  while (gbl_offload_signal != HPCG_OFFLOAD_RUN) {};
  t4min = gbl_offload_dbl;

  gbl_offload_dbl = t4;
  gbl_offload_signal = HPCG_OFFLOAD_ALLRED_DBL_MAX;
  while (gbl_offload_signal != HPCG_OFFLOAD_RUN) {};
  t4max = gbl_offload_dbl;

  gbl_offload_dbl = t4;
  gbl_offload_signal = HPCG_OFFLOAD_ALLRED_DBL_SUM;
  while (gbl_offload_signal != HPCG_OFFLOAD_RUN) {};
  t4avg = gbl_offload_dbl;
#endif
  t4avg = t4avg/((double) A.geom->size);
#endif

  // initialize YAML doc

  if (A.geom->rank==0) { // Only PE 0 needs to compute and report timing results

    double fNumberOfCgSets = numberOfCgSets;
    double fniters = fNumberOfCgSets * (double) optMaxIters;
    double fnrow = A.totalNumberOfRows;
    double fnnz = A.totalNumberOfNonzeros;

    // Op counts come from implementation of CG in CG.cpp (include 1 extra for the CG preamble ops)
    double fnops_ddot = (3.0*fniters+fNumberOfCgSets)*2.0*fnrow; // 3 ddots with nrow adds and nrow mults
    double fnops_waxpby = (3.0*fniters+fNumberOfCgSets)*2.0*fnrow; // 3 WAXPBYs with nrow adds and nrow mults
    double fnops_sparsemv = (fniters+fNumberOfCgSets)*2.0*fnnz; // 1 SpMV with nnz adds and nnz mults
    // Op counts from the multigrid preconditioners
    double fnops_precond = 0.0;
    const SparseMatrix * Af = &A;
    for (int i=1; i<numberOfMgLevels; ++i) {
        double fnnz_Af = Af->totalNumberOfNonzeros;
        double fnumberOfPresmootherSteps = Af->mgData->numberOfPresmootherSteps;
        double fnumberOfPostsmootherSteps = Af->mgData->numberOfPostsmootherSteps;
        fnops_precond += fnumberOfPresmootherSteps*fniters*4.0*fnnz_Af; // number of presmoother flops
        fnops_precond += fniters*2.0*fnnz_Af; // cost of fine grid residual calculation
        fnops_precond += fnumberOfPostsmootherSteps*fniters*4.0*fnnz_Af;  // number of postsmoother flops
    	Af = Af->Ac; // Go to next coarse level
    }

    fnops_precond += fniters*4.0*((double) Af->totalNumberOfNonzeros); // One symmetric GS sweep at the coarsest level
    double fnops = fnops_ddot+fnops_waxpby+fnops_sparsemv+fnops_precond;
    double reffnops = fnops * ((double) refMaxIters)/((double) optMaxIters);

    char buf[1024];
    if (params.nx < 0) {
      char *lastSlash = strrchr((char *)params.inputMatrixFileName, '/');
      if (!lastSlash) {
        lastSlash = (char *)params.inputMatrixFileName;
      }
      else {
        lastSlash++;
      }
      printf("%s\n", lastSlash);
      sprintf(buf, "%s-%dp-%dt", lastSlash, params.comm_size, A.geom->numThreads);
    }
    else {
      sprintf(buf, "n%d-%dp-%dt", A.geom->nx, params.comm_size, A.geom->numThreads);
    }
    std::string fileName(buf);
    if (params.multiColorFromThisLevel < params.numberOfMgLevels) {
      sprintf(buf, "-color-%d-%d", params.multiColorFromThisLevel, params.colorBlockSize);
      fileName += buf;
    }

    YAML_Doc doc(fileName, "2.4", "", params.yamlFileName);

    doc.add("Machine Summary","");
    doc.get("Machine Summary")->add("Distributed Processes",A.geom->size);
    doc.get("Machine Summary")->add("Threads per processes",A.geom->numThreads);

    doc.add("Option Summary", "");
#if defined(__MIC__) || defined(__AVX512F__)
    doc.get("Option Summary")->add("esb", params.useEsb);
#endif
    if (params.multiColorFromThisLevel < 256) {
      doc.get("Option Summary")->add("multi-coloring", params.multiColorFromThisLevel);
      if (params.blockColorUpToThisLevel > 0) {
        doc.get("Option Summary")->add("block-color-up-to-level", params.blockColorUpToThisLevel);
      }
      if (params.colorBlockSize > 1) {
        doc.get("Option Summary")->add("color-block", params.colorBlockSize);
        //doc.get("Option Summary")->add("block-method", toString(params.blockMethod).c_str());
      }
    }
    if (params.numberOfPresmootherSteps != 1) {
      doc.get("Option Summary")->add("pre-smoother-steps", params.numberOfPresmootherSteps);
    }
    if (params.numberOfPostsmootherSteps != 1) {
      doc.get("Option Summary")->add("post-smoother-steps", params.numberOfPostsmootherSteps);
    }
    if (params.fuseSpmv) {
      doc.get("Option Summary")->add("fuse-spmv", params.fuseSpmv);
    }
    if (params.overlap) {
      doc.get("Option Summary")->add("overlap", params.overlap);
    }
    if (!params.runRef) {
      doc.get("Option Summary")->add("run-ref", params.runRef);
    }
    if (!params.runRealRef) {
      doc.get("Option Summary")->add("run-real-ref", params.runRealRef);
    }
#ifdef HPCG_DEBUG
    doc.get("Option Summary")->add("debug", true);
#endif

    doc.add("Global Problem Dimensions","");
    doc.get("Global Problem Dimensions")->add("Global nx",A.geom->npx*A.geom->nx);
    doc.get("Global Problem Dimensions")->add("Global ny",A.geom->npy*A.geom->ny);
    doc.get("Global Problem Dimensions")->add("Global nz",A.geom->npz*A.geom->nz);

    doc.add("Processor Dimensions","");
    doc.get("Processor Dimensions")->add("npx",A.geom->npx);
    doc.get("Processor Dimensions")->add("npy",A.geom->npy);
    doc.get("Processor Dimensions")->add("npz",A.geom->npz);

    doc.add("Local Domain Dimensions","");
    doc.get("Local Domain Dimensions")->add("nx",A.geom->nx);
    doc.get("Local Domain Dimensions")->add("ny",A.geom->ny);
    doc.get("Local Domain Dimensions")->add("nz",A.geom->nz);

    doc.add("########## Problem Summary  ##########","");

    doc.add("Setup Information","");
    doc.get("Setup Information")->add("Setup Time",times[9]);

    doc.add("Linear System Information","");
    doc.get("Linear System Information")->add("Number of Equations",A.totalNumberOfRows);
    doc.get("Linear System Information")->add("Number of Nonzero Terms",A.totalNumberOfNonzeros);

    doc.add("Multigrid Information","");
    doc.get("Multigrid Information")->add("Number of coarse grid levels", numberOfMgLevels-1);
    Af = &A;
    doc.get("Multigrid Information")->add("Coarse Grids","");
    for (int i=1; i<numberOfMgLevels; ++i) {
        doc.get("Multigrid Information")->get("Coarse Grids")->add("Grid Level",i);
        doc.get("Multigrid Information")->get("Coarse Grids")->add("Number of Equations",Af->Ac->totalNumberOfRows);
        doc.get("Multigrid Information")->get("Coarse Grids")->add("Number of Nonzero Terms",Af->Ac->totalNumberOfNonzeros);
        doc.get("Multigrid Information")->get("Coarse Grids")->add("Number of Presmoother Steps",Af->mgData->numberOfPresmootherSteps);
        doc.get("Multigrid Information")->get("Coarse Grids")->add("Number of Postsmoother Steps",Af->mgData->numberOfPostsmootherSteps);
    	Af = Af->Ac;
    }

    doc.add("########## Validation Testing Summary  ##########","");
    doc.add("Spectral Convergence Tests","");
    if (testcg_data.count_fail==0)
      doc.get("Spectral Convergence Tests")->add("Result", "PASSED");
    else
      doc.get("Spectral Convergence Tests")->add("Result", "FAILED");
    doc.get("Spectral Convergence Tests")->add("Unpreconditioned","");
    doc.get("Spectral Convergence Tests")->get("Unpreconditioned")->add("Maximum iteration count", testcg_data.niters_max_no_prec);
    doc.get("Spectral Convergence Tests")->get("Unpreconditioned")->add("Expected iteration count", testcg_data.expected_niters_no_prec);
    doc.get("Spectral Convergence Tests")->add("Preconditioned","");
    doc.get("Spectral Convergence Tests")->get("Preconditioned")->add("Maximum iteration count", testcg_data.niters_max_prec);
    doc.get("Spectral Convergence Tests")->get("Preconditioned")->add("Expected iteration count", testcg_data.expected_niters_prec);

    const char DepartureFromSymmetry[] = "Departure from Symmetry |x'Ay-y'Ax|/(2*||x||*||A||*||y||)/epsilon";
    doc.add(DepartureFromSymmetry,"");
    if (testsymmetry_data.count_fail==0)
      doc.get(DepartureFromSymmetry)->add("Result", "PASSED");
    else
      doc.get(DepartureFromSymmetry)->add("Result", "FAILED");
    doc.get(DepartureFromSymmetry)->add("Departure for SpMV", testsymmetry_data.depsym_spmv);
    doc.get(DepartureFromSymmetry)->add("Departure for MG", testsymmetry_data.depsym_mg);

    doc.add("########## Iterations Summary  ##########","");
    doc.add("Iteration Count Information","");
    if (!global_failure)
      doc.get("Iteration Count Information")->add("Result", "PASSED");
    else
      doc.get("Iteration Count Information")->add("Result", "FAILED");
//    printf("Average iterations per set = %f\n", fniters/fNumberOfCgSets);
    doc.get("Iteration Count Information")->add("Reference CG iterations per set", refMaxIters);
    doc.get("Iteration Count Information")->add("Optimized CG iterations per set", optMaxIters);
    doc.get("Iteration Count Information")->add("Total number of reference iterations", refMaxIters*numberOfCgSets);
    doc.get("Iteration Count Information")->add("Total number of optimized iterations", optMaxIters*numberOfCgSets);

    doc.add("########## Reproducibility Summary  ##########","");
    doc.add("Reproducibility Information","");
    if (testnorms_data.pass)
      doc.get("Reproducibility Information")->add("Result", "PASSED");
    else
      doc.get("Reproducibility Information")->add("Result", "FAILED");
    doc.get("Reproducibility Information")->add("Scaled residual mean", testnorms_data.mean);
    doc.get("Reproducibility Information")->add("Scaled residual variance", testnorms_data.variance);

    doc.add("########## Performance Summary (times in sec) ##########","");

    doc.add("Benchmark Time Summary","");
    doc.get("Benchmark Time Summary")->add("Optimization phase",times[7]);
    doc.get("Benchmark Time Summary")->add("DDOT",times[1]);
    doc.get("Benchmark Time Summary")->add("WAXPBY",times[2]);
    doc.get("Benchmark Time Summary")->add("SpMV",times[3]);
    doc.get("Benchmark Time Summary")->add("MG",times[5]);
    doc.get("Benchmark Time Summary")->add("  forward", forwardTime);
    doc.get("Benchmark Time Summary")->add("  backward", backwardTime);
    for (int i = 0; i < params.numberOfMgLevels; ++i) {
      char buf[1024];
      sprintf(buf, "  Level %d", i);
      doc.get("Benchmark Time Summary")->add(buf, mgTimes[i]);
      if (i < params.numberOfMgLevels - 1) {
        doc.get("Benchmark Time Summary")->add("    Pre-smooth", preSmoothTimes[i]);
        doc.get("Benchmark Time Summary")->add("    Post-smooth", postSmoothTimes[i]);
        doc.get("Benchmark Time Summary")->add("    SpMV", spmvTimes[i]);
        doc.get("Benchmark Time Summary")->add("    Restriction", restrictionTimes[i]);
        doc.get("Benchmark Time Summary")->add("    Prolongation", prolongationTimes[i]);
      }
    }
#ifndef HPCG_NO_MPI
    double haloTotalTime =
      haloTimes[SETUP_PERSISTENT_COMM] +
      haloTimes[START_RECV] +
      haloTimes[FILL_UP_SEND_BUF] +
      haloTimes[START_SEND] +
      haloTimes[WAIT];
    if (params.measureImbalance) {
      haloTotalTime += haloTimes[IMBALANCE];
    }

    doc.get("Benchmark Time Summary")->add("Halo",haloTotalTime);
    doc.get("Benchmark Time Summary")->add("  Setup",haloTimes[SETUP_PERSISTENT_COMM]);
    if (params.measureImbalance)
      doc.get("Benchmark Time Summary")->add("  Imbalance",haloTimes[IMBALANCE]);
    doc.get("Benchmark Time Summary")->add("  Start-recv",haloTimes[START_RECV]);
    doc.get("Benchmark Time Summary")->add("  Fill-up-send-buf",haloTimes[FILL_UP_SEND_BUF]);
    doc.get("Benchmark Time Summary")->add("  Start-send",haloTimes[START_SEND]);
    doc.get("Benchmark Time Summary")->add("  Wait",haloTimes[WAIT]);
#endif
    doc.get("Benchmark Time Summary")->add("Total",times[0]);

    doc.add("Floating Point Operations Summary","");
    doc.get("Floating Point Operations Summary")->add("Raw DDOT",fnops_ddot);
    doc.get("Floating Point Operations Summary")->add("Raw WAXPBY",fnops_waxpby);
    doc.get("Floating Point Operations Summary")->add("Raw SpMV",fnops_sparsemv);
    doc.get("Floating Point Operations Summary")->add("Raw MG",fnops_precond);
    doc.get("Floating Point Operations Summary")->add("Total",fnops);
    doc.get("Floating Point Operations Summary")->add("Total with convergence overhead",reffnops);

    doc.add("GFLOP/s Summary","");
    doc.get("GFLOP/s Summary")->add("Raw DDOT",fnops_ddot/times[1]/1.0E9);
    doc.get("GFLOP/s Summary")->add("Raw WAXPBY",fnops_waxpby/times[2]/1.0E9);
    doc.get("GFLOP/s Summary")->add("Raw SpMV",fnops_sparsemv/(times[3])/1.0E9);
    doc.get("GFLOP/s Summary")->add("Raw MG",fnops_precond/(times[5])/1.0E9);
    Af = &A;
    for (int i = 0; i < params.numberOfMgLevels; ++i) {
      char buf[1024];
      sprintf(buf, "  Level %d", i);

      if (i < params.numberOfMgLevels - 1) {
        double fnnz_Af = Af->totalNumberOfNonzeros;
        double fnumberOfPresmootherSteps = Af->mgData->numberOfPresmootherSteps;
        double fnumberOfPostsmootherSteps = Af->mgData->numberOfPostsmootherSteps;
        double fnops_presmooth = fnumberOfPresmootherSteps*fniters*4.0*fnnz_Af;
        double fnops_postsmooth = fnumberOfPostsmootherSteps*fniters*4.0*fnnz_Af;
        double fnops_spmv = fniters*2.0*fnnz_Af;
        double fnops = fnops_presmooth + fnops_postsmooth + fnops_spmv;

        doc.get("GFLOP/s Summary")->add(buf, fnops/mgTimes[i]/1.0E9);
        doc.get("GFLOP/s Summary")->add("    Pre-smooth", fnops_presmooth/preSmoothTimes[i]/1.0E9);
        doc.get("GFLOP/s Summary")->add("    Post-smooth", fnops_postsmooth/postSmoothTimes[i]/1.0E9);
        doc.get("GFLOP/s Summary")->add("    SpMV", fnops_spmv/spmvTimes[i]/1.0E9);
      }
      else {
        double fnops = fniters*4.0*((double)Af->totalNumberOfNonzeros);

        doc.get("GFLOP/s Summary")->add(buf, fnops/mgTimes[i]/1.0E9);
      }

      Af = Af->Ac;
    }
    doc.get("GFLOP/s Summary")->add("Raw Total",fnops/times[0]/1.0E9);
    doc.get("GFLOP/s Summary")->add("Total with convergence overhead",reffnops/times[0]/1.0E9);
//    printf("GFLOP/s with convergence overhead = %f\n",reffnops/times[0]/1.0E9);
    // Still compute Gflops in HPCG 2.4 way until we settle down on 3.0
    totalGflops = reffnops/(times[0]+fNumberOfCgSets*times[7]/10.0)/1.0E9;
    // This final GFLOP/s rating for HPCG 3.0 includes the overhead of problem setup and optimizing the data structures vs ten sets of 50 iterations of CG
    double totalGflopsVer3 = reffnops/(times[0]+fNumberOfCgSets*(times[7]/10.0+times[9]))/1.0E9;
    doc.get("GFLOP/s Summary")->add("Total with convergence and optimization phase overhead",totalGflops);
    doc.get("GFLOP/s Summary")->add("Total with convergence and optimization phase overhead (HPCG 3.0)",totalGflopsVer3);
//    printf("GFLOP/s with convergence and optimization phase overhead = %f\n",totalGflops);
//    printf("GFLOP/s with convergence and optimization phase overhead (HPCG 3.0) = %f\n",totalGflopsVer3);

    doc.add("User Optimization Overheads","");
    doc.get("User Optimization Overheads")->add("Problem setup time (sec)", (times[9]));
    doc.get("User Optimization Overheads")->add("Optimization phase time (sec)", (times[7]));
//    printf("Optimization phase time = %f\n", times[7]);
//    printf("Optimization phase time = %f\n", times[7]);
    doc.get("User Optimization Overheads")->add("Optimization phase time vs reference SpMV+MG time", times[7]/times[8]);

#ifndef HPCG_NO_MPI
    doc.add("DDOT Timing Variations","");
    doc.get("DDOT Timing Variations")->add("Min DDOT MPI_Allreduce time",t4min);
    doc.get("DDOT Timing Variations")->add("Max DDOT MPI_Allreduce time",t4max);
    doc.get("DDOT Timing Variations")->add("Avg DDOT MPI_Allreduce time",t4avg);

    //doc.get("Sparse Operations Overheads")->add("Halo exchange time (sec)", (times[6]));
    //doc.get("Sparse Operations Overheads")->add("Halo exchange as percentage of SpMV time", (times[6])/totalSparseMVTime*100.0);
#endif
    doc.add("__________ Final Summary __________","");
    bool isValidRun = (testcg_data.count_fail==0) && (testsymmetry_data.count_fail==0) && (testnorms_data.pass) && (!global_failure);
    if (isValidRun) {
      doc.get("__________ Final Summary __________")->add("HPCG result is VALID with a GFLOP/s rating of", totalGflops);
/*
      if (!A.isDotProductOptimized) {
        doc.get("__________ Final Summary __________")->add("Reference version of ComputeDotProduct used","Performance results are most likely suboptimal");
      }
      if (!A.isSpmvOptimized) {
        doc.get("__________ Final Summary __________")->add("Reference version of ComputeSPMV used","Performance results are most likely suboptimal");
      }
      if (!A.isMgOptimized) {
        if (A.geom->numThreads>1)
          doc.get("__________ Final Summary __________")->add("Reference version of ComputeMG used and number of threads greater than 1","Performance results are severely suboptimal");
        else // numThreads ==1
          doc.get("__________ Final Summary __________")->add("Reference version of ComputeMG used","Performance results are most likely suboptimal");
      }
      if (!A.isWaxpbyOptimized) {
        doc.get("__________ Final Summary __________")->add("Reference version of ComputeWAXPBY used","Performance results are most likely suboptimal");
      }
*/
      if (times[0]>=minOfficialTime) {
        doc.get("__________ Final Summary __________")->add("Please send the YAML file contents to","HPCG-Results@software.sandia.gov");
      }
      else {
          doc.get("__________ Final Summary __________")->add("Results are valid but execution time (sec) is",times[0]);
          doc.get("__________ Final Summary __________")->add("Official results execution time (sec) must be at least",minOfficialTime);

      }
    } else {
      printf("INVALID!\n");
      doc.get("__________ Final Summary __________")->add("HPCG result is","INVALID.");
      doc.get("__________ Final Summary __________")->add("Please review the YAML file contents","You may NOT submit these results for consideration.");
    }

    std::string yaml = doc.generateYAML();
#ifdef HPCG_DEBUG
#ifndef HPCG_OFFLOAD
    HPCG_fout << yaml;
    fflush(stdout);
#endif
#endif
  }
  return totalGflops;
}
