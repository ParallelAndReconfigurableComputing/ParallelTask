/******************************************************************************
*  Copyright(C) 2014 Intel Corporation. All rights reserved.
*
*  The source code, information  and  material ("Material") contained herein is
*  owned  by Intel Corporation or its suppliers or licensors, and title to such
*  Material remains  with Intel Corporation  or its suppliers or licensors. The
*  Material  contains proprietary information  of  Intel or  its  suppliers and
*  licensors. The  Material is protected by worldwide copyright laws and treaty
*  provisions. No  part  of  the  Material  may  be  used,  copied, reproduced,
*  modified, published, uploaded, posted, transmitted, distributed or disclosed
*  in any way  without Intel's  prior  express written  permission. No  license
*  under  any patent, copyright  or  other intellectual property rights  in the
*  Material  is  granted  to  or  conferred  upon  you,  either  expressly,  by
*  implication, inducement,  estoppel or  otherwise.  Any  license  under  such
*  intellectual  property  rights must  be express  and  approved  by  Intel in
*  writing.
*
*  *Third Party trademarks are the property of their respective owners.
*
*  Unless otherwise  agreed  by Intel  in writing, you may not remove  or alter
*  this  notice or  any other notice embedded  in Materials by Intel or Intel's
*  suppliers or licensors in any way.
*
*******************************************************************************/

//@HEADER
// ***************************************************
//
// HPCG: High Performance Conjugate Gradient Benchmark
//
// Contact:
// Michael A. Heroux ( maherou@sandia.gov)
// Jack Dongarra     (dongarra@eecs.utk.edu)
// Piotr Luszczek    (luszczek@eecs.utk.edu)
//
// ***************************************************
//@HEADER

/*!
 @file ComputeDotProduct.cpp

 HPCG routine
 */

#include "ComputeDotProduct.hpp"
#include "ComputeDotProduct_ref.hpp"

/*!
  Routine to compute the dot product of two vectors.

  This routine calls the reference dot-product implementation by default, but
  can be replaced by a custom routine that is optimized and better suited for
  the target system.

  @param[in]  n the number of vector elements (on this processor)
  @param[in]  x, y the input vectors
  @param[out] result a pointer to scalar value, on exit will contain the result.
  @param[out] time_allreduce the time it took to perform the communication between processes
  @param[out] isOptimized should be set to false if this routine uses the reference implementation (is not optimized); otherwise leave it unchanged

  @return returns 0 upon success and non-zero otherwise

  @see ComputeDotProduct_ref
*/
int ComputeDotProduct(const local_int_t n, const Vector & x, const Vector & y,
    double & result, double & time_allreduce, bool & isOptimized) {
  return ComputeDotProduct_ref(n, x, y, result, time_allreduce);
}
