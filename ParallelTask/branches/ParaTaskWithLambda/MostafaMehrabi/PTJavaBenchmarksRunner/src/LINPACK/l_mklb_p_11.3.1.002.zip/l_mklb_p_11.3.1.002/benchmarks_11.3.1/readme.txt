This package contains the Intel(R) Optimized LINPACK Benchmark, Intel(R) 
Optimized MP LINPACK Benchmark for Clusters, and Intel(R) Optimized High 
Performance Conjugate Gradient Benchmark for Linux* OS.

Please refer to the chapter "Intel MKL Benchmarks" in online version of Intel(R) 
Math Kernel Library (Intel(R) MKL) User's Guide 
(http://software.intel.com/en-us/mkl-for-linux-userguide) and readme files in 
individual benchmark directories for usage instructions.

These benchmarks are also included in the full product distributions of Intel(R)
Math Kernel Library 11.3.1 for Linux* OS (http://www.intel.com/software/products/mkl).

* Other names and brands may be claimed as the property of others.
