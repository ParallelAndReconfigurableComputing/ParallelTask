/******************************************************************************
*  Copyright(C) 2014 Intel Corporation. All rights reserved.
*
*  The source code, information  and  material ("Material") contained herein is
*  owned  by Intel Corporation or its suppliers or licensors, and title to such
*  Material remains  with Intel Corporation  or its suppliers or licensors. The
*  Material  contains proprietary information  of  Intel or  its  suppliers and
*  licensors. The  Material is protected by worldwide copyright laws and treaty
*  provisions. No  part  of  the  Material  may  be  used,  copied, reproduced,
*  modified, published, uploaded, posted, transmitted, distributed or disclosed
*  in any way  without Intel's  prior  express written  permission. No  license
*  under  any patent, copyright  or  other intellectual property rights  in the
*  Material  is  granted  to  or  conferred  upon  you,  either  expressly,  by
*  implication, inducement,  estoppel or  otherwise.  Any  license  under  such
*  intellectual  property  rights must  be express  and  approved  by  Intel in
*  writing.
*
*  *Third Party trademarks are the property of their respective owners.
*
*  Unless otherwise  agreed  by Intel  in writing, you may not remove  or alter
*  this  notice or  any other notice embedded  in Materials by Intel or Intel's
*  suppliers or licensors in any way.
*
*******************************************************************************/

//@HEADER
// ***************************************************
//
// HPCG: High Performance Conjugate Gradient Benchmark
//
// Contact:
// Michael A. Heroux ( maherou@sandia.gov)
// Jack Dongarra     (dongarra@eecs.utk.edu)
// Piotr Luszczek    (luszczek@eecs.utk.edu)
//
// ***************************************************
//@HEADER

/*!
 @file ComputeSPMV_ref.cpp

 HPCG routine
 */

#include "ComputeSPMV_ref.hpp"

#ifndef HPCG_NO_MPI
#include "ExchangeHalo.hpp"
#endif

#ifndef HPCG_NO_OPENMP
#include <omp.h>
#endif
#include <cassert>

/*!
  Routine to compute matrix vector product y = Ax where:
  Precondition: First call exchange_externals to get off-processor values of x

  This is the reference SPMV implementation.  It CANNOT be modified for the
  purposes of this benchmark.

  @param[in]  A the known system matrix
  @param[in]  x the known vector
  @param[out] y the On exit contains the result: Ax.

  @return returns 0 upon success and non-zero otherwise

  @see ComputeSPMV
*/
int ComputeSPMV_ref( const SparseMatrix & A, Vector & x, Vector & y) {

  assert(x.localLength>=A.localNumberOfColumns); // Test vector lengths
  assert(y.localLength>=A.localNumberOfRows);

#ifndef HPCG_NO_MPI
  ExchangeHalo(A,x,NULL,HPCG_Params());
#endif
  const double * const xv = x.values;
  double * const yv = y.values;
  const local_int_t nrow = A.localNumberOfRows;
#ifndef HPCG_NO_OPENMP
  #pragma omp parallel for
#endif
  for (local_int_t i=0; i< nrow; i++)  {
    double sum = 0.0;
    const double * const cur_vals = A.matrixValues[i];
    const local_int_t * const cur_inds = A.mtxIndL[i];
    const int cur_nnz = A.nonzerosInRow[i];

    for (int j=0; j< cur_nnz; j++)
      sum += cur_vals[j]*xv[cur_inds[j]];
    yv[i] = sum;
  }
  return 0;
}
