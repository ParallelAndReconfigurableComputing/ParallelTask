/******************************************************************************
*  Copyright(C) 2014 Intel Corporation. All rights reserved.
*
*  The source code, information  and  material ("Material") contained herein is
*  owned  by Intel Corporation or its suppliers or licensors, and title to such
*  Material remains  with Intel Corporation  or its suppliers or licensors. The
*  Material  contains proprietary information  of  Intel or  its  suppliers and
*  licensors. The  Material is protected by worldwide copyright laws and treaty
*  provisions. No  part  of  the  Material  may  be  used,  copied, reproduced,
*  modified, published, uploaded, posted, transmitted, distributed or disclosed
*  in any way  without Intel's  prior  express written  permission. No  license
*  under  any patent, copyright  or  other intellectual property rights  in the
*  Material  is  granted  to  or  conferred  upon  you,  either  expressly,  by
*  implication, inducement,  estoppel or  otherwise.  Any  license  under  such
*  intellectual  property  rights must  be express  and  approved  by  Intel in
*  writing.
*
*  *Third Party trademarks are the property of their respective owners.
*
*  Unless otherwise  agreed  by Intel  in writing, you may not remove  or alter
*  this  notice or  any other notice embedded  in Materials by Intel or Intel's
*  suppliers or licensors in any way.
*
*******************************************************************************/

//@HEADER
// ***************************************************
//
// HPCG: High Performance Conjugate Gradient Benchmark
//
// Contact:
// Michael A. Heroux ( maherou@sandia.gov)
// Jack Dongarra     (dongarra@eecs.utk.edu)
// Piotr Luszczek    (luszczek@eecs.utk.edu)
//
// ***************************************************
//@HEADER

/*!
 @file SetupHalo.cpp

 HPCG routine
 */

#ifndef HPCG_NO_MPI
#include <unordered_set>
#include <map>
#include <set>
#include "mpi_hpcg.hpp"
#endif

#ifndef HPCG_NO_OPENMP
#include <omp.h>
#endif

#include "hpcg.hpp"
#include "SetupHalo.hpp"
#include "SetupHalo_ref.hpp"
#include "OptimizeProblem.hpp"

using namespace std;

/*!
  Prepares system matrix data structure and creates data necessary necessary
  for communication of boundary values of this process.

  @param[inout] A    The known system matrix

  @see ExchangeHalo
*/
void SetupHalo(SparseMatrix & A) {

  // The call to this reference version of SetupHalo can be replaced with custom code.
  // However, any code must work for general unstructured sparse matrices.  Special knowledge about the
  // specific nature of the sparsity pattern may not be explicitly used.
  //return(SetupHalo_ref(A));

  // Extract Matrix pieces

  local_int_t localNumberOfRows = A.localNumberOfRows;
  char  * nonzerosInRow = A.nonzerosInRow;
  global_int_t ** mtxIndG = A.mtxIndG;
  local_int_t ** mtxIndL = A.mtxIndL;

#ifdef HPCG_NO_MPI  // In the non-MPI case we simply copy global indices to local index storage
#ifndef HPCG_NO_OPENMP
  #pragma omp parallel for
#endif
  for (local_int_t i=0; i< localNumberOfRows; i++) {
    int cur_nnz = nonzerosInRow[i];
    for (int j=0; j<cur_nnz; j++) mtxIndL[i][j] = mtxIndG[i][j];
  }

#else // HPCG_NO_MPI - Run this section if compiling for MPI

  // Scan global IDs of the nonzeros in the matrix.  Determine if the column ID matches a row ID.  If not:
  // 1) We call the ComputeRankOfMatrixRow function, which tells us the rank of the processor owning the row ID.
  //  We need to receive this value of the x vector during the halo exchange.
  // 2) We record our row ID since we know that the other processor will need this value from us, due to symmetry.

  unordered_map< int, unordered_set< local_int_t> > tempSendList[omp_get_max_threads()];
  unordered_map< int, unordered_set< global_int_t> > tempReceiveList[omp_get_max_threads()];
  typedef set<local_int_t>::iterator set_iter1;
  typedef set<global_int_t>::iterator set_iter2;
  unordered_map< local_int_t, local_int_t > externalToLocalMap;

#pragma omp parallel for
  for (local_int_t i=0; i< A.numOfBoundaryRows; i++) {
    global_int_t currentLocalRow = A.boundaryRows[i];
    for (int j=0; j<nonzerosInRow[currentLocalRow]; j++) {
      global_int_t curIndex = mtxIndG[currentLocalRow][j];
#ifdef HPCG_DETAILED_DEBUG
      HPCG_fout << "rank, row , col, globalToLocalMap[col] = " << A.geom->rank << " " << currentGlobalRow << " "
          << curIndex << " " << A.globalToLocalMap[curIndex] << endl;
#endif
      if (mtxIndL[currentLocalRow][j] < 0) {// If column index is not a row index, then it comes from another processor
        int rankIdOfColumnEntry = -mtxIndL[currentLocalRow][j] - 1;
        tempReceiveList[omp_get_thread_num()][rankIdOfColumnEntry].insert(curIndex);
        tempSendList[omp_get_thread_num()][rankIdOfColumnEntry].insert(currentLocalRow); // Matrix symmetry means we know the neighbor process wants my value
      }
    }
  }

  int sumOfTempReceiveListSizes = 0;
  for (int i = 0; i < omp_get_max_threads(); i++) {
    sumOfTempReceiveListSizes += tempReceiveList[i].size();
  }
  int * neighbors = new int[sumOfTempReceiveListSizes];
  int j = 0;
  for (int i = 0; i < omp_get_max_threads(); i++) {
    for (auto itr : tempReceiveList[i]) {
      neighbors[j++] = itr.first;
    }
  }
  sort(neighbors, neighbors + sumOfTempReceiveListSizes);
  int neighborCount = unique(neighbors, neighbors + sumOfTempReceiveListSizes) - neighbors;

  // both sendList and receiveList need to have sorted list to be consistent with peers
  set<local_int_t> sendList[neighborCount];
  set<global_int_t> receiveList[neighborCount];

#pragma omp parallel for
  for (int i = 0; i < neighborCount*2; i++) {
    int neighbor = neighbors[i/2];
    if (i%2 == 0) {
      for (int tid = 0; tid < omp_get_num_threads(); tid++) {
        if (tempSendList[tid].find(neighbor) != tempSendList[tid].end()) {
          sendList[i/2].insert(tempSendList[tid][neighbor].begin(), tempSendList[tid][neighbor].end());
          tempSendList[tid][neighbor].clear();
        }
      }
    }
    else {
      for (int tid = 0; tid < omp_get_num_threads(); tid++) {
        if (tempReceiveList[tid].find(neighbor) != tempReceiveList[tid].end()) {
          receiveList[i/2].insert(tempReceiveList[tid][neighbor].begin(), tempReceiveList[tid][neighbor].end());
          tempReceiveList[tid][neighbor].clear();
        }
      }
    }
  }

  // Count number of matrix entries to send and receive
  local_int_t totalToBeSent = 0;
  local_int_t totalToBeReceived = 0;
  for (int i = 0; i < neighborCount; i++) {
    totalToBeSent += sendList[i].size();
    totalToBeReceived += receiveList[i].size();
  }

#ifdef HPCG_DETAILED_DEBUG
  // These are all attributes that should be true, due to symmetry
  HPCG_fout << "totalToBeSent = " << totalToBeSent << " totalToBeReceived = " << totalToBeReceived << endl;
  assert(totalToBeSent==totalToBeReceived); // Number of sent entry should equal number of received
  assert(sendList.size()==receiveList.size()); // Number of send-to neighbors should equal number of receive-from
  // Each receive-from neighbor should be a send-to neighbor, and send the same number of entries
  for (map_iter2 curNeighbor = receiveList.begin(); curNeighbor != receiveList.end(); ++curNeighbor) {
    assert(sendList.find(curNeighbor->first)!=sendList.end());
    assert(sendList[curNeighbor->first].size()==receiveList[curNeighbor->first].size());
  }
#endif

  // Build the arrays and lists needed by the ExchangeHalo function.
  double * sendBuffer = new double[totalToBeSent];
  local_int_t * elementsToSend = new local_int_t[totalToBeSent];
  local_int_t * receiveLength = new local_int_t[neighborCount];
  local_int_t * sendLength = new local_int_t[neighborCount];
  local_int_t receiveEntryCount = 0;
  local_int_t sendEntryCount = 0;

  //temp_t = omp_get_wtime();
  for (int i = 0; i < neighborCount; i++) {
    receiveLength[i] = receiveList[i].size();
    sendLength[i] = sendList[i].size(); // Get count if sends/receives
    for (set_iter2 itr = receiveList[i].begin(); itr != receiveList[i].end(); ++itr, ++receiveEntryCount) {
      externalToLocalMap[*itr] = localNumberOfRows + receiveEntryCount; // The remote columns are indexed at end of internals
    }
    for (set_iter1 itr = sendList[i].begin(); itr != sendList[i].end(); ++itr, ++sendEntryCount) {
      //if (geom.rank==1) HPCG_fout << "*itr, globalToLocalMap[*itr], sendEntryCount = " << *itr << " " << A.globalToLocalMap[*itr] << " " << sendEntryCount << endl;
      elementsToSend[sendEntryCount] = *itr; // store local ids of entry to send
    }
  }

  // Convert matrix indices to local IDs
#ifndef HPCG_NO_OPENMP
  #pragma omp parallel for
#endif
  for (local_int_t i=0; i< A.numOfBoundaryRows; i++) {
    local_int_t row = A.boundaryRows[i];
    for (int j=0; j<nonzerosInRow[row]; j++) {
      global_int_t curIndex = mtxIndG[row][j];
      if (mtxIndL[row][j] < 0) { // If column index is not a row index, then it comes from another processor
        mtxIndL[row][j] = externalToLocalMap[curIndex];
      }
      assert(mtxIndL[row][j] < A.localNumberOfRows + externalToLocalMap.size());
    }
  }

  // Store contents in our matrix struct
  A.numberOfExternalValues = externalToLocalMap.size();
  A.externalToLocalMap.swap(externalToLocalMap);
  A.localNumberOfColumns = A.localNumberOfRows + A.numberOfExternalValues;
  A.numberOfSendNeighbors = neighborCount;
  A.totalToBeSent = totalToBeSent;
  A.elementsToSend = elementsToSend;
  A.neighbors = neighbors;
  A.receiveLength = receiveLength;
  A.sendLength = sendLength;
  A.sendBuffer = sendBuffer;

#ifdef HPCG_DETAILED_DEBUG
  HPCG_fout << " For rank " << A.geom->rank << " of " << A.geom->size << ", number of neighbors = " << A.numberOfSendNeighbors << endl;
  for (int i = 0; i < A.numberOfSendNeighbors; i++) {
    HPCG_fout << "     rank " << A.geom->rank << " neighbor " << neighbors[i] << " send/recv length = " << sendLength[i] << "/" << receiveLength[i] << endl;
    for (local_int_t j = 0; j<sendLength[i]; ++j)
      HPCG_fout << "       rank " << A.geom->rank << " elementsToSend[" << j << "] = " << elementsToSend[j] << endl;
  }
#endif

#ifdef HPCG_NEIGHBORHOOD_COLLECTIVES
  *((MPI_Comm *)A.halo_neighborhood_comm) = MPI_COMM_NULL;
# elif defined(HPCG_RMA_FENCE) || defined(HPCG_RMA_FLUSH)
  int num_neighbors = A.numberOfSendNeighbors; /*  = sendList.size()  */
  MPI_Aint total_offset = 0;
  for (int i = 0; i < num_neighbors; i++) {
    total_offset += sendLength[i];
  }
  total_offset *= sizeof(double);

  /* HPCG_RMA_METHOD = PSCW, FENCE, LOCK, FLUSH all use this */
  MPI_Win_create(A.sendBuffer, total_offset, sizeof(double),
                 MPI_INFO_NULL, MPI_COMM_WORLD, (MPI_Win *)A.send_window );
#  if defined(HPCG_RMA_FLUSH)
  MPI_Win_lock_all(0, *((MPI_Win *)A.send_window));
#  endif // HPCG_RMA_FLUSH
# endif // NEIGHBORHOOD, RMA

#endif // ifndef HPCG_NO_MPI

  return;
}
