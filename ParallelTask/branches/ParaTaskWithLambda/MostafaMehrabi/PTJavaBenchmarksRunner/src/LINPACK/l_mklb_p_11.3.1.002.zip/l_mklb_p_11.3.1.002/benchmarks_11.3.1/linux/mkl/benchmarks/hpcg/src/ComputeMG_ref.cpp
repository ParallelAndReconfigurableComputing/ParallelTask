/******************************************************************************
*  Copyright(C) 2014 Intel Corporation. All rights reserved.
*
*  The source code, information  and  material ("Material") contained herein is
*  owned  by Intel Corporation or its suppliers or licensors, and title to such
*  Material remains  with Intel Corporation  or its suppliers or licensors. The
*  Material  contains proprietary information  of  Intel or  its  suppliers and
*  licensors. The  Material is protected by worldwide copyright laws and treaty
*  provisions. No  part  of  the  Material  may  be  used,  copied, reproduced,
*  modified, published, uploaded, posted, transmitted, distributed or disclosed
*  in any way  without Intel's  prior  express written  permission. No  license
*  under  any patent, copyright  or  other intellectual property rights  in the
*  Material  is  granted  to  or  conferred  upon  you,  either  expressly,  by
*  implication, inducement,  estoppel or  otherwise.  Any  license  under  such
*  intellectual  property  rights must  be express  and  approved  by  Intel in
*  writing.
*
*  *Third Party trademarks are the property of their respective owners.
*
*  Unless otherwise  agreed  by Intel  in writing, you may not remove  or alter
*  this  notice or  any other notice embedded  in Materials by Intel or Intel's
*  suppliers or licensors in any way.
*
*******************************************************************************/

//@HEADER
// ***************************************************
//
// HPCG: High Performance Conjugate Gradient Benchmark
//
// Contact:
// Michael A. Heroux ( maherou@sandia.gov)
// Jack Dongarra     (dongarra@eecs.utk.edu)
// Piotr Luszczek    (luszczek@eecs.utk.edu)
//
// ***************************************************
//@HEADER

/*!
 @file ComputeSYMGS_ref.cpp

 HPCG routine
 */

#include "ComputeMG_ref.hpp"
#include "ComputeSYMGS_ref.hpp"
#include "ComputeSPMV_ref.hpp"
#include "ComputeRestriction_ref.hpp"
#include "ComputeProlongation_ref.hpp"
#include <cassert>
#include <iostream>

using namespace std;

extern void checkProgress(int rank, int size, const char *msg, int seconds = 10);

/*!

  @param[in] A the known system matrix
  @param[in] r the input vector
  @param[inout] x On exit contains the result of the multigrid V-cycle with r as the RHS, x is the approximation to Ax = r.

  @return returns 0 upon success and non-zero otherwise

  @see ComputeMG
*/
int ComputeMG_ref(const SparseMatrix & A, const Vector & r, Vector & x, int level, const HPCG_Params& params) {
  assert(x.localLength==A.localNumberOfColumns); // Make sure x contain space for halo values

  ZeroVector(x); // initialize x to zero

  int ierr = 0;
  if (A.mgData!=0) { // Go to next coarse level if defined
    int numberOfPresmootherSteps = A.mgData->numberOfPresmootherSteps;
    for (int i=0; i< 1/*numberOfPresmootherSteps*/; ++i) ierr += ComputeSYMGS_ref(A, r, x);

    if (params.logLevel >= 5) {
      HPCG_fout << "[" << A.geom->rank << "] PreSYMGS:" << level << " finished." << endl;
    }

    if (ierr!=0) return ierr;

    ierr = ComputeSPMV_ref(A, x, *A.mgData->Axf); if (ierr!=0) return ierr;

    if (params.logLevel >= 5) {
      HPCG_fout << "[" << A.geom->rank << "] SPMV:" << level << " finished." << endl;
    }

    // Perform restriction operation using simple injection
    ierr = ComputeRestriction_ref(A, r);  if (ierr!=0) return ierr;
    ierr = ComputeMG_ref(*A.Ac,*A.mgData->rc, *A.mgData->xc, level + 1, params);  if (ierr!=0) return ierr;
    ierr = ComputeProlongation_ref(A, x);  if (ierr!=0) return ierr;
    int numberOfPostsmootherSteps = A.mgData->numberOfPostsmootherSteps;
    for (int i=0; i< 1/*numberOfPostsmootherSteps*/; ++i) ierr += ComputeSYMGS_ref(A, r, x);

    if (params.logLevel >= 5) {
      HPCG_fout << "[" << A.geom->rank << "] PostSYMGS:" << level << " finished." << endl;
    }

    if (ierr!=0) return ierr;
  }
  else {
    ierr = ComputeSYMGS_ref(A, r, x);
    if (ierr!=0) return ierr;

    if (params.logLevel >= 5) {
      HPCG_fout << "[" << A.geom->rank << "] SYMGS:" << level << " finished." << endl;
    }
  }
  return 0;
}

