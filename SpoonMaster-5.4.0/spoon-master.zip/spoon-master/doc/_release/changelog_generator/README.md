# Changelog Generator

## Usage
```
node node changelog.js <previous-spoon-version>
```

## Install
```
npm install
```